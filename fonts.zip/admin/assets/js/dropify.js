
$(function() {
  'use strict';

  $('#catImage').dropify();

});