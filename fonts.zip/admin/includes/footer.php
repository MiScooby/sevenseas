</div>


<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-center text-center px-4 py-3 border-top small">
    <p class="text-muted mb-1 mb-md-0">Copyright © 2023.All Rights Reserved By <a href="https://maishainfotech.com/" target="_blank">Maishainfotech Pvt. Ltd.</a></p>
</footer>


</div>
</div>


<!-- core:js -->
<script src="assets/vendors/core/core.js"></script>
<!-- endinject -->

<!-- Plugin js for this page -->
<script src="assets/vendors/flatpickr/flatpickr.min.js"></script>
<script src="assets/vendors/apexcharts/apexcharts.min.js"></script>
<!-- End plugin js for this page -->

<!-- inject:js -->
<script src="assets/vendors/feather-icons/feather.min.js"></script>
<script src="assets/js/template.js"></script>
<!-- endinject -->

<!-- Custom js for this page -->
<script src="assets/js/dashboard-light.js"></script>
<!-- End custom js for this page -->

<script src="assets/js/jquery.magnific-popup.min.js"></script>

<script src="assets/sweetalert2/sweetalert2.min.js"></script>

<script src="assets/vendors/datatables.net/jquery.dataTables.js"></script>
<script src="assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js"></script>
<script src="assets/vendors/select2/select2.min.js"></script>
<script src="assets/vendors/dropify/dist/dropify.min.js"></script>
<script src="js/main.js"></script>

 
</body>

</html>