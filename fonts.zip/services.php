﻿<?php include('includes/header.php') ?>


<section class="page-title" style="background-image: url(images/background/page-title.jpg);">
    <div class="auto-container">
        <div class="title-outer">
            <h1 class="title">Our Services</h1>
            <ul class="page-breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li><a href="javascript:">Pages</a></li>
                <li>Services</li>
            </ul>
        </div>
    </div>
</section>

<!-- Services section -->
<section class="ansh_ser services-section">
    <div class="auto-container">
        <div class="row">
            <div class="col-lg-6">
                <div class="sec-title">
                    <span class="sub-title">What do we offer</span>
                    <h2>Outstanding visa visa <span class="color3">services.</span></h2>
                    <div class="text">Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem is simply free text quis bibendum.</div>
                </div>
            </div>

            <div class="service-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="javascript:;"><img src="images/resource/service-1.jpg" alt=""></a></figure>
                        <i class="icon fa fa-graduation-cap"></i>
                        <h6 class="title">Student Visa</h6>
                    </div>
                    <div class="content-box">
                        <h6 class="title"><a href="javascript:;">Student Visa</a></h6>
                        <div class="text">We have to a tendency to believe the idea that smart looking of any website.</div>
                        <a href="javascript:;" class="read-more">More <i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="service-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="200ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="javascript:;"><img src="images/resource/service-2.jpg" alt=""></a></figure>
                        <i class="icon fa fa-briefcase"></i>
                        <h6 class="title">Business Visa</h6>
                    </div>
                    <div class="content-box">
                        <h6 class="title"><a href="javascript:;">Business Visa</a></h6>
                        <div class="text">We have to a tendency to believe the idea that smart looking of any website.</div>
                        <a href="javascript:;" class="read-more">More <i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="service-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="javascript:;"><img src="images/resource/service-3.jpg" alt=""></a></figure>
                        <i class="icon fa fa-family"></i>
                        <h6 class="title">Family Visa</h6>
                    </div>
                    <div class="content-box">
                        <h6 class="title"><a href="javascript:;">Family Visa</a></h6>
                        <div class="text">We have to a tendency to believe the idea that smart looking of any website.</div>
                        <a href="javascript:;" class="read-more">More <i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="service-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="200ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="javascript:;"><img src="images/resource/service-4.jpg" alt=""></a></figure>
                        <i class="icon fa fa-camera"></i>
                        <h6 class="title">Tourist Visa</h6>
                    </div>
                    <div class="content-box">
                        <h6 class="title"><a href="javascript:;">Tourist Visa</a></h6>
                        <div class="text">We have to a tendency to believe the idea that smart looking of any website.</div>
                        <a href="javascript:;" class="read-more">More <i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="service-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="400ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="javascript:;"><img src="images/resource/service-5.jpg" alt=""></a></figure>
                        <i class="icon fa fa-home"></i>
                        <h6 class="title">Residence Visa</h6>
                    </div>
                    <div class="content-box">
                        <h6 class="title"><a href="javascript:;">Residence Visa</a></h6>
                        <div class="text">We have to a tendency to believe the idea that smart looking of any website.</div>
                        <a href="javascript:;" class="read-more">More <i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="cta-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                <div class="inner-box">
                    <h4 class="title"><a href="javascript:;">Get visa with 100% success rate</a></h4>
                    <a href="javascript:;" class="theme-btn btn-style-three small">Apply Now</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- process section -->
<section class="process-section">
    <div class="dotted-map"></div>
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">our work process</span>
            <h2>Get your visa approved in <br>3 easy simple <span class="color3">steps</span></h2>
        </div>
        <div class="row">

            <div class="process-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="icon-box">
                        <i class="icon flaticon-form"></i>
                        <span class="count">01</span>
                    </div>
                    <div class="info-box">
                        <div class="inner">
                            <h6 class="title">Complete Online Form</h6>
                            <div class="text">Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="process-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="400ms">
                <div class="inner-box">
                    <div class="icon-box">
                        <i class="icon flaticon-documents"></i>
                        <span class="count">02</span>
                    </div>
                    <div class="info-box">
                        <div class="inner">
                            <h6 class="title">Documents & Payments</h6>
                            <div class="text">Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="process-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="800ms">
                <div class="inner-box">
                    <div class="icon-box">
                        <i class="icon flaticon-visa-3"></i>
                        <span class="count">03</span>
                    </div>
                    <div class="info-box">
                        <div class="inner">
                            <h6 class="title">Receive Your Visa</h6>
                            <div class="text">Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- fecture Sections -->
<section class="features-section ansh-fet">
    <div class="auto-container">
        <div class="sec-title text-center">
            <h2>Process For Student <span class="color3">Visas</span></h2>
        </div>
        <div class="row">

            <div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <figure class="image"><img src="images/resource/feature-1.jpg" alt=""></figure>
                    <a href="#" class="theme-btn btn-style-one step">Apply for New Visa</a>
                    <div class="overlay-content">
                        <div class="title-box">
                            <i class="icon flaticon-immigration-1"></i>
                            <h6 class="title">Apply for New Visa</h6>
                        </div>
                        <div class="text">Neque porro quisqum est qui dolorem ipsum quia dolor. tellus est aliquet egetristique nisullam.</div>
                        <a href="page-service.html" class="theme-btn btn-style-three read-more">Read More</a>
                    </div>
                </div>
            </div>

            <div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                <div class="inner-box">
                    <figure class="image"><img src="images/resource/feature-2.jpg" alt=""></figure>
                    <a href="#" class="theme-btn btn-style-one step">Immigration Program</a>
                    <div class="overlay-content">
                        <div class="title-box">
                            <i class="icon flaticon-immigration-1"></i>
                            <h6 class="title">Immigration Program</h6>
                        </div>
                        <div class="text">Neque porro quisqum est qui dolorem ipsum quia dolor. tellus est aliquet egetristique nisullam.</div>
                        <a href="page-service.html" class="theme-btn btn-style-three read-more">Read More</a>
                    </div>
                </div>
            </div>

            <div class="feature-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                <div class="inner-box">
                    <figure class="image"><img src="images/resource/feature-3.jpg" alt=""></figure>
                    <a href="#" class="theme-btn btn-style-one step">Required Documents</a>
                    <div class="overlay-content">
                        <div class="title-box">
                            <i class="icon flaticon-immigration-1"></i>
                            <h6 class="title">Required Documents</h6>
                        </div>
                        <div class="text">Neque porro quisqum est qui dolorem ipsum quia dolor. tellus est aliquet egetristique nisullam.</div>
                        <a href="page-service.html" class="theme-btn btn-style-three read-more">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Countries Section -->
<section class="countries-section-two">
    <div class="outer-box">
        <div class="bg bg-pattern-3"></div>
        <div class="auto-container">
            <div class="row">

                <div class="title-column col-lg-6 col-md-12 wow fadeInLeft">
                    <div class="inner-column">
                        <div class="sec-title">
                            <span class="sub-title">countries you can visit</span>
                            <h2>Countries we support <br>for the <span class="color3">immigration</span></h2>
                            <div class="text">There cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs condmentum leo massa mollis. our unmatched approach to business and cost effectiveness consulting</div>
                        </div>
                        <a href="page-country.html" class="theme-btn btn-style-one">Explore More</a>
                    </div>
                </div>

                <div class="content-column col-lg-6 col-md-12 wow fadeInRight" data-wow-delay="300ms">
                    <div class="row">

                        <div class="country-block-two col-lg-4 col-md-4 col-sm-6">
                            <div class="inner-box">
                                <div class="flag"><img src="images/resource/flag-1.png" alt=""></div>
                                <h6 class="title">Australia</h6>
                            </div>
                        </div>

                        <div class="country-block-two col-lg-4 col-md-4 col-sm-6" data-wow-delay="300ms">
                            <div class="inner-box">
                                <div class="flag"><img src="images/resource/flag-2.png" alt=""></div>
                                <h6 class="title">Germany</h6>
                            </div>
                        </div>

                        <div class="country-block-two col-lg-4 col-md-4 col-sm-6" data-wow-delay="600ms">
                            <div class="inner-box">
                                <div class="flag"><img src="images/resource/flag-3.png" alt=""></div>
                                <h6 class="title">Brazil</h6>
                            </div>
                        </div>

                        <div class="country-block-two col-lg-4 col-md-4 col-sm-6">
                            <div class="inner-box">
                                <div class="flag"><img src="images/resource/flag-4.png" alt=""></div>
                                <h6 class="title">Russia</h6>
                            </div>
                        </div>

                        <div class="country-block-two col-lg-4 col-md-4 col-sm-6" data-wow-delay="300ms">
                            <div class="inner-box">
                                <div class="flag"><img src="images/resource/flag-5.png" alt=""></div>
                                <h6 class="title">England</h6>
                            </div>
                        </div>

                        <div class="country-block-two col-lg-4 col-md-4 col-sm-6" data-wow-delay="600ms">
                            <div class="inner-box">
                                <div class="flag"><img src="images/resource/flag-6.png" alt=""></div>
                                <h6 class="title">India</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="carousel-outer">
        </div>
    </div>
</section>

<?php include('includes/footer.php') ?>